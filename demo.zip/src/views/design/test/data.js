import { prod3dData, prodData } from '@/views/design/test/prodData';
import { ProdItem } from '@/views/design/interface/prodItem';
import { Prod3dItem } from '@/views/design/interface/prod3dItem';

export const prodList = prodData.map((e) => new ProdItem(e));

export const prod3dList = prod3dData.map((e) => new Prod3dItem(e));
