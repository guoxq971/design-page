import { loadModel } from '@/views/design/three/utils/loadModel';
import { ModelItem, ModelViewItem } from '@/views/design/three/interface/modelItem';
import { draw } from '@/views/design/three/utils/modelViewUtil';
import { createCanvasTexture } from '@/views/design/three/utils/createTexture';

/**
 * 加载3d数据(new ModelItem)
 * @param prod 产品数据
 * @returns {Promise<ModelItem>}
 * */
export async function loadModelItem(prod) {
  // const path = prod.prod3d.glbPath;
  const path = './XXS.glb';

  // 加载模型
  const { model, meshList } = await loadModel(path);

  // 初始化模型数据
  const modelItem = new ModelItem();
  modelItem.model = model;
  modelItem.prod = prod;
  modelItem.viewList = getViewList(prod, meshList);

  return modelItem;
}

/**
 * 获取模型视图列表
 * @param {object} prod 产品数据
 * @param {array} meshList 模型网格列表
 * @return {array} 模型视图列表
 * */
function getViewList(prod, meshList) {
  const prod3d = prod.prod3d; // 3d的接口数据
  const prodViewList = prod.viewList; // 2d视图列表

  return prod3d.viewList.map((v) => {
    // 模型视图对应的2d视图数据
    const prodView = prodViewList.find((item) => item.id == v.viewId);
    // 模型视图对应的网格
    const mesh = findMesh(meshList, v.materialName);

    // 初始化模型视图数据
    const modelView = new ModelViewItem();
    modelView.prodView = prodView; //可能没有
    modelView.viewConfig = v;
    modelView.colorConfig = getColorConfig(prod, v);
    modelView.mesh = mesh;
    modelView.material = mesh.material;

    if (prodView) {
      mesh.material.map = createCanvas(modelView);
      modelView.texture = mesh.material.map;
      mesh.material.map.image = prodView.fabricCanvas.canvas.lowerCanvasEl;
      prodView.fabricCanvas.addEvent(() => draw(modelView));
    }

    return modelView;
  });
}

/**
 * 创建画布
 * @param {object} modelView 3d视图数据
 * @return {object} 画布
 * */
function createCanvas(modelView) {
  if (modelView.prodView) {
    return createCanvasTexture();
  } else {
    // return createCanvasTexture();
  }
}

/**
 * 获取3d颜色对象
 * @param {object} prod 产品数据
 * @param {object} modelView 3d视图数据
 * @return {object} 3d颜色对象
 * */
function getColorConfig(prod, modelView) {
  // 当前选中的颜色
  const activeProdColor = prod.activeColor;
  // 当前选中的颜色对应的3d颜色配置
  const modelColor = prod.prod3d.colorList.find((e) => e.colorName === activeProdColor.name);

  return modelColor?.list.find((e) => e.materialName === modelView.materialName);
}

/**
 * 查找网格
 * @param {array} meshList 模型网格列表
 * @param {string} materialName 材质名称
 * @return {Mesh} 网格
 * */
function findMesh(meshList, materialName) {
  // [iron_sheet, iron sheet], materialName如果存在下划线，会被分割成两个字符串
  const names = [materialName];

  if (materialName.indexOf('_') > -1) {
    names.push(materialName.replace('_', ' '));
  }

  return meshList.find((mesh) => names.includes(mesh.name));
}
