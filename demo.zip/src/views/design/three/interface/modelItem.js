export class ModelItem {
  model; //模型
  prod; //产品对象
  viewList = []; //模型视图列表
}

export class ModelViewItem {
  mesh; //模型网格
  material; //模型材质
  texture; //模型纹理

  prodView; //2d视图 new ViewItem
  viewConfig; //3d视图配置的接口数据
  colorConfig; //3d颜色配置的接口数据
}
